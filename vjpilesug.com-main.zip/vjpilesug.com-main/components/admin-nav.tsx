"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { signOut } from "firebase/auth"
import { auth } from "@/lib/firebase"
import { useRouter } from "next/navigation"
import { LayoutDashboard, Users, ImageIcon, Film, Tv, Star, Sparkles, Music, Wallet, LogOut, Home } from "lucide-react"

export default function AdminNav() {
  const pathname = usePathname()
  const router = useRouter()

  const handleLogout = async () => {
    await signOut(auth)
    router.push("/login")
  }

  const navItems = [
    { href: "/", label: "Home", icon: Home },
    { href: "/admin", label: "Dashboard", icon: LayoutDashboard },
    { href: "/admin/users", label: "Users", icon: Users },
    { href: "/admin/carousel", label: "Carousel", icon: ImageIcon },
    { href: "/admin/movies", label: "Movies", icon: Film },
    { href: "/admin/series", label: "Series", icon: Tv },
    { href: "/admin/originals", label: "Originals", icon: Star },
    { href: "/admin/animation", label: "Animation", icon: Sparkles },
    { href: "/admin/music", label: "Music", icon: Music },
    { href: "/admin/wallet", label: "Wallet", icon: Wallet },
  ]

  return (
    <nav className="fixed top-0 left-0 right-0 bg-card/95 backdrop-blur-md border-b border-border z-40">
      <div className="grid grid-cols-11 w-full">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = pathname === item.href
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex flex-col items-center justify-center py-2 transition-colors ${
                isActive ? "bg-[#e50914] text-white" : "text-muted-foreground hover:text-foreground hover:bg-muted"
              }`}
            >
              <Icon className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="text-[8px] sm:text-[10px] md:text-xs font-medium truncate max-w-full px-0.5">
                {item.label}
              </span>
            </Link>
          )
        })}

        {/* Logout button */}
        <button
          onClick={handleLogout}
          className="flex flex-col items-center justify-center py-2 bg-red-600 hover:bg-red-700 text-white transition-colors"
        >
          <LogOut className="w-4 h-4 sm:w-5 sm:h-5" />
          <span className="text-[8px] sm:text-[10px] md:text-xs font-medium">Logout</span>
        </button>
      </div>
    </nav>
  )
}
