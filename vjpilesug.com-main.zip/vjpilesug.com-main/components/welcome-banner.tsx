"use client"

import { useEffect, useState } from "react"
import { database } from "@/lib/firebase"
import { ref, get } from "firebase/database"
import { X } from "lucide-react"
import Image from "next/image"

interface ContentItem {
  id: string
  title: string
  image: string
  type: string
  createdAt?: string
}

interface CarouselItem {
  id: string
  title: string
  image: string
  createdAt?: string
}

const WELCOME_EXPIRY_TIME = 10 * 60 * 1000

export default function WelcomeBanner() {
  const [isVisible, setIsVisible] = useState(false)
  const [latestContent, setLatestContent] = useState<ContentItem[]>([])
  const [latestCarouselImage, setLatestCarouselImage] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const welcomeDismissedAt = localStorage.getItem("vjpiles_welcome_dismissed_at")

    if (welcomeDismissedAt) {
      const dismissedTime = Number.parseInt(welcomeDismissedAt, 10)
      const currentTime = Date.now()

      if (currentTime - dismissedTime >= WELCOME_EXPIRY_TIME) {
        localStorage.removeItem("vjpiles_welcome_dismissed_at")
        setIsVisible(true)
        fetchLatestContent()
      } else {
        setLoading(false)
      }
    } else {
      setIsVisible(true)
      fetchLatestContent()
    }
  }, [])

  const fetchLatestContent = async () => {
    try {
      const [moviesSnap, seriesSnap, originalsSnap, carouselSnap] = await Promise.all([
        get(ref(database, "movies")),
        get(ref(database, "series")),
        get(ref(database, "originals")),
        get(ref(database, "carousel")),
      ])

      // Process carousel
      const carouselItems: CarouselItem[] = []
      if (carouselSnap.exists()) {
        Object.entries(carouselSnap.val()).forEach(([id, data]: [string, any]) => {
          carouselItems.push({
            id,
            title: data.title,
            image: data.image,
            createdAt: data.createdAt,
          })
        })
      }

      carouselItems.sort((a, b) => {
        const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0
        const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0
        return dateB - dateA
      })
      if (carouselItems.length > 0) {
        setLatestCarouselImage(carouselItems[0].image)
      }

      // Process content
      const allContent: ContentItem[] = []

      const processSnapshot = (snap: any, type: string) => {
        if (snap.exists()) {
          Object.entries(snap.val()).forEach(([id, data]: [string, any]) => {
            allContent.push({
              id,
              title: data.title,
              image: data.image,
              type,
              createdAt: data.createdAt,
            })
          })
        }
      }

      processSnapshot(moviesSnap, "Movies")
      processSnapshot(seriesSnap, "Series")
      processSnapshot(originalsSnap, "Originals")

      allContent.sort((a, b) => {
        const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0
        const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0
        return dateB - dateA
      })

      setLatestContent(allContent.slice(0, 5))
    } catch (error) {
      console.error("Error fetching latest content:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleClose = () => {
    setIsVisible(false)
    localStorage.setItem("vjpiles_welcome_dismissed_at", Date.now().toString())
  }

  if (!isVisible || loading) {
    return null
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="relative w-full max-w-2xl aspect-[16/9] rounded-xl overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-300">
        {/* Close Button */}
        <button
          onClick={handleClose}
          className="absolute top-2 right-2 z-20 w-6 h-6 rounded-full bg-black/50 hover:bg-black/70 flex items-center justify-center transition-colors"
        >
          <X className="w-3 h-3 text-white" />
        </button>

        <div className="absolute inset-0">
          {latestCarouselImage ? (
            <Image
              src={latestCarouselImage || "/placeholder.svg"}
              alt="Featured content"
              fill
              className="object-cover object-top"
              priority
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-[#0a1628] via-[#0d2847] to-[#1a3a5c]" />
          )}
          {/* Gradient overlay for readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a1628] via-[#0a1628]/60 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0a1628]/80 via-transparent to-transparent" />
        </div>

        {/* Content container */}
        <div className="relative h-full flex flex-col justify-end z-10">
          {/* Left side - Logo and text */}
          <div className="absolute left-4 md:left-6 bottom-[40%]">
            <div className="mb-1">
              <h1 className="text-lg md:text-2xl font-black text-white tracking-tight">
                VJ PILES<span className="text-[#e50914]">+</span>
              </h1>
            </div>
            <p className="text-white/90 text-[10px] md:text-xs font-medium leading-snug mb-2">
              All this and more
              <br />
              available now
            </p>
            <button
              onClick={handleClose}
              className="w-fit px-3 md:px-4 py-1 md:py-1.5 bg-[#e50914] hover:bg-[#f6121d] rounded-md text-white font-semibold text-[10px] md:text-xs transition-all hover:scale-105 active:scale-95"
            >
              Start Watching
            </button>
          </div>

          {/* Bottom section - Poster grid - smaller posters */}
          <div className="w-full px-3 md:px-6 pb-3 md:pb-4">
            <div className="flex items-end justify-center gap-1.5 md:gap-2">
              {latestContent.map((item, index) => (
                <div
                  key={item.id}
                  className="relative flex flex-col items-center group"
                  style={{
                    transform: `perspective(1000px) rotateY(${-5 + index * 2.5}deg)`,
                    zIndex: latestContent.length - index,
                  }}
                >
                  {/* Poster card - smaller size */}
                  <div
                    className="relative rounded overflow-hidden shadow-lg transition-transform duration-300 group-hover:scale-105 group-hover:-translate-y-1"
                    style={{
                      width: "clamp(40px, 10vw, 80px)",
                      height: "clamp(60px, 15vw, 120px)",
                    }}
                  >
                    <Image src={item.image || "/placeholder.svg"} alt={item.title} fill className="object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                  </div>

                  {/* Category badge - smaller */}
                  <div className="mt-1 px-1 py-0.5 bg-white/10 backdrop-blur-sm rounded text-[6px] md:text-[8px] text-white/90 font-medium uppercase tracking-wider">
                    {item.type}
                  </div>

                  {/* Title - smaller */}
                  <p className="mt-0.5 text-[6px] md:text-[8px] text-white/70 text-center max-w-[45px] md:max-w-[70px] line-clamp-1">
                    {item.title}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Copyright - smaller */}
          <div className="absolute left-4 md:left-6 bottom-2">
            <p className="text-white/40 text-[6px] md:text-[8px]">© 2025 VJ Piles UG Movies. All rights reserved.</p>
          </div>
        </div>
      </div>
    </div>
  )
}
