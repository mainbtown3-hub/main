"use client"

import { Search, User, LogOut } from "lucide-react"
import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import { signOut } from "firebase/auth"
import { auth } from "@/lib/firebase"
import SearchBar from "./search-bar"
import AuthModal from "./auth-modal"

interface MobileHeaderProps {
  onSearch?: (query: string) => void
}

export default function MobileHeader({ onSearch }: MobileHeaderProps) {
  const [searchOpen, setSearchOpen] = useState(false)
  const [authModalOpen, setAuthModalOpen] = useState(false)
  const [userMenuOpen, setUserMenuOpen] = useState(false)
  const { user } = useAuth()
  const router = useRouter()

  const handleUserClick = () => {
    if (user) {
      setUserMenuOpen(!userMenuOpen)
    } else {
      setAuthModalOpen(true)
    }
  }

  const handleLogout = async () => {
    try {
      await signOut(auth)
      setUserMenuOpen(false)
      router.push("/")
    } catch (error) {
      console.error("Logout failed:", error)
    }
  }

  return (
    <>
      <div className="md:hidden sticky top-0 z-40 bg-[#141620] border-b border-[#2a2d3a] px-3 py-2">
        <div className="flex items-center justify-between gap-3">
          <button onClick={() => router.push("/")} className="flex-shrink-0">
            <span className="text-white font-bold text-sm">VJ PILES UG MOVIES</span>
          </button>

          {/* Search and Account */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSearchOpen(!searchOpen)}
              className="p-2 text-[#9ca3af] hover:text-white transition"
            >
              <Search className="w-5 h-5" />
            </button>

            <div className="relative">
              <button onClick={handleUserClick} className="p-2 text-[#9ca3af] hover:text-white transition">
                {user ? (
                  <div className="w-7 h-7 bg-gradient-to-br from-pink-400 to-purple-500 rounded-full flex items-center justify-center">
                    <User className="w-4 h-4 text-white" />
                  </div>
                ) : (
                  <User className="w-5 h-5" />
                )}
              </button>

              {user && userMenuOpen && (
                <div className="absolute right-0 top-full mt-2 w-48 bg-[#1e2130] border border-[#2a2d3a] rounded-lg shadow-lg overflow-hidden z-50">
                  <div className="px-4 py-3 border-b border-[#2a2d3a]">
                    <p className="text-white text-sm font-medium truncate">{user.email}</p>
                    <p className="text-[#9ca3af] text-xs">Logged in</p>
                  </div>
                  <button
                    onClick={() => {
                      router.push("/settings")
                      setUserMenuOpen(false)
                    }}
                    className="w-full flex items-center gap-3 px-4 py-3 text-[#9ca3af] hover:text-white hover:bg-[#2a2d3a] transition text-left"
                  >
                    <User className="w-4 h-4" />
                    <span className="text-sm">Settings</span>
                  </button>
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center gap-3 px-4 py-3 text-red-400 hover:text-red-300 hover:bg-[#2a2d3a] transition text-left"
                  >
                    <LogOut className="w-4 h-4" />
                    <span className="text-sm">Logout</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Search Bar Expansion */}
        {searchOpen && (
          <div className="mt-2 pb-1">
            <SearchBar />
          </div>
        )}
      </div>

      {userMenuOpen && <div className="md:hidden fixed inset-0 z-30" onClick={() => setUserMenuOpen(false)} />}

      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onSuccess={() => setAuthModalOpen(false)}
      />
    </>
  )
}
