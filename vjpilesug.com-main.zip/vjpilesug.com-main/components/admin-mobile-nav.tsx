"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { LayoutDashboard, Users, Film, Tv, Star, Sparkles, Music, Wallet, ImageIcon, Home } from "lucide-react"

export default function AdminMobileNav() {
  const pathname = usePathname()

  const navItems = [
    { href: "/", label: "Home", icon: Home },
    { href: "/admin", label: "Dash", icon: LayoutDashboard },
    { href: "/admin/users", label: "Users", icon: Users },
    { href: "/admin/carousel", label: "Slide", icon: ImageIcon },
    { href: "/admin/movies", label: "Movies", icon: Film },
    { href: "/admin/series", label: "Series", icon: Tv },
    { href: "/admin/originals", label: "Origin", icon: Star },
    { href: "/admin/animation", label: "Anim", icon: Sparkles },
    { href: "/admin/music", label: "Music", icon: Music },
    { href: "/admin/wallet", label: "Wallet", icon: Wallet },
  ]

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-card/95 backdrop-blur-md border-t border-border z-50 safe-area-bottom">
      <div className="grid grid-cols-10 w-full">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = pathname === item.href
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex flex-col items-center justify-center py-2 transition-colors ${
                isActive ? "bg-[#e50914] text-white" : "text-muted-foreground hover:text-foreground hover:bg-muted"
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="text-[7px] font-medium truncate max-w-full px-0.5">{item.label}</span>
            </Link>
          )
        })}
      </div>
    </nav>
  )
}
