import type React from "react"
import type { Metadata, Viewport } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import { AuthProvider } from "@/lib/auth-context"
import { SubscriptionProvider } from "@/lib/subscription-context"
import { ThemeProvider } from "@/components/theme-provider"
import "./globals.css"

const _geist = Geist({ subsets: ["latin"] })
const _geistMono = Geist_Mono({ subsets: ["latin"] })

export const metadata: Metadata = {
  metadataBase: new URL("https://vjpilesug.com"),
  title: {
    default: "VJ Piles UG - Luo Translated Movies | Stream & Download African Movies",
    template: "%s | VJ Piles UG Movies",
  },
  description:
    "VJ Piles UG - The #1 platform for Luo translated movies in Uganda. Stream and download the best Hollywood, Bollywood, and African movies translated to Luo language by VJ Piles. Wod Paco entertainment.",
  keywords: [
    "VJ Piles UG",
    "VJ Piles",
    "Luo translated movies",
    "Luo movies",
    "Uganda movies",
    "African movies",
    "translated movies",
    "movie translation",
    "Wod Paco",
    "VJ Piles movies",
    "Luo language movies",
    "Uganda entertainment",
    "stream movies Uganda",
    "download Luo movies",
    "VJ translation",
    "Acholi movies",
    "East African movies",
    "Hollywood Luo",
    "Bollywood Luo translation",
    "VJ Piles UG movies",
    "free Luo movies",
    "watch Luo movies online",
    "best Luo translator",
    "VJ Piles Wod Paco",
    "Ugandan movie translator",
  ],
  authors: [{ name: "VJ Piles UG", url: "https://vjpilesug.com" }],
  creator: "VJ Piles UG",
  publisher: "VJ Piles UG",
  generator: "Next.js",
  manifest: "/manifest.json",
  applicationName: "VJ Piles UG Movies",
  referrer: "origin-when-cross-origin",
  category: "entertainment",
  classification: "Movies & Entertainment",
  robots: {
    index: true,
    follow: true,
    nocache: false,
    googleBot: {
      index: true,
      follow: true,
      noimageindex: false,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  openGraph: {
    type: "website",
    locale: "en_UG",
    url: "https://vjpilesug.com",
    siteName: "VJ Piles UG Movies",
    title: "VJ Piles UG - Luo Translated Movies | Stream & Download",
    description:
      "The #1 platform for Luo translated movies in Uganda. Stream and download Hollywood, Bollywood, and African movies translated to Luo by VJ Piles - Wod Paco.",
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "VJ Piles UG - Luo Translated Movies",
        type: "image/png",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "VJ Piles UG - Luo Translated Movies",
    description:
      "Stream & download Luo translated movies by VJ Piles UG. Hollywood, Bollywood & African movies in Luo language.",
    images: ["/og-image.png"],
    creator: "@vjpilesug",
    site: "@vjpilesug",
  },
  alternates: {
    canonical: "https://vjpilesug.com",
    languages: {
      "en-UG": "https://vjpilesug.com",
    },
  },
  icons: {
    icon: [
      { url: "/favicon.ico", sizes: "any" },
      { url: "/favicon.png", type: "image/png" },
    ],
    shortcut: "/favicon.png",
    apple: "/favicon.png",
    other: [
      {
        rel: "apple-touch-icon",
        url: "/favicon.png",
      },
    ],
  },
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "VJ Piles UG",
    startupImage: "/favicon.png",
  },
  formatDetection: {
    telephone: true,
    email: true,
    address: true,
  },
  verification: {
    google: "your-google-verification-code",
    yandex: "your-yandex-verification-code",
    other: {
      "msvalidate.01": "your-bing-verification-code",
    },
  },
  other: {
    "geo.region": "UG",
    "geo.placename": "Uganda",
    "og:locale:alternate": "sw_KE",
    "content-language": "en-UG",
  },
}

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#141620" },
  ],
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
  colorScheme: "dark light",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "WebSite",
              name: "VJ Piles UG Movies",
              alternateName: ["VJ Piles", "Wod Paco", "VJ Piles UG"],
              url: "https://vjpilesug.com",
              description:
                "The #1 platform for Luo translated movies in Uganda. Stream and download Hollywood, Bollywood, and African movies translated to Luo by VJ Piles.",
              publisher: {
                "@type": "Organization",
                name: "VJ Piles UG",
                logo: {
                  "@type": "ImageObject",
                  url: "https://vjpilesug.com/favicon.png",
                },
              },
              potentialAction: {
                "@type": "SearchAction",
                target: {
                  "@type": "EntryPoint",
                  urlTemplate: "https://vjpilesug.com/search?q={search_term_string}",
                },
                "query-input": "required name=search_term_string",
              },
              sameAs: [
                "https://www.facebook.com/vjpilesug",
                "https://www.youtube.com/@vjpilesug",
                "https://www.tiktok.com/@vjpilesug",
                "https://twitter.com/vjpilesug",
                "https://www.instagram.com/vjpilesug",
              ],
            }),
          }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Organization",
              name: "VJ Piles UG",
              alternateName: "Wod Paco",
              url: "https://vjpilesug.com",
              logo: "https://vjpilesug.com/favicon.png",
              description:
                "VJ Piles UG - Professional Luo movie translator. Watch the best translated movies in Luo language.",
              foundingDate: "2020",
              foundingLocation: "Uganda",
              areaServed: ["Uganda", "Kenya", "Tanzania", "East Africa"],
              knowsLanguage: ["en", "luo", "sw"],
              slogan: "Wod Paco - Best Luo Translated Movies",
            }),
          }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "VideoGallery",
              name: "VJ Piles UG Movie Collection",
              description: "Collection of Luo translated movies by VJ Piles UG",
              url: "https://vjpilesug.com",
              provider: {
                "@type": "Organization",
                name: "VJ Piles UG",
              },
            }),
          }}
        />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="dns-prefetch" href="https://vjpilesug.com" />
      </head>
      <body className={`font-sans antialiased`}>
        <ThemeProvider defaultTheme="dark" attribute="class" enableSystem>
          <AuthProvider>
            <SubscriptionProvider>{children}</SubscriptionProvider>
          </AuthProvider>
        </ThemeProvider>
        <Analytics />
      </body>
    </html>
  )
}
