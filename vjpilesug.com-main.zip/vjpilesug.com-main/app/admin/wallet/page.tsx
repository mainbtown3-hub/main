"use client"

import type React from "react"

import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import Sidebar from "@/components/sidebar"
import AdminNav from "@/components/admin-nav"
import AdminMobileNav from "@/components/admin-mobile-nav"
import { Card } from "@/components/ui/card"
import { DollarSign, TrendingUp, ArrowDownToLine, Loader2 } from "lucide-react"

async function fetchWalletBalance() {
  const url = `https://vjpilesug.okotstephen57.workers.dev/api/wallet/balance`
  try {
    const response = await fetch(url)
    const data = await response.json()
    console.log("[v0] Balance API Response:", data)
    return data
  } catch (err: any) {
    console.error("[v0] Balance API Error:", err)
    return { success: false, error: err.message }
  }
}

async function fetchTransactions() {
  const url = `https://vjpilesug.okotstephen57.workers.dev/api/transactions`
  try {
    const response = await fetch(url)
    const data = await response.json()
    console.log("[v0] Transactions API Response:", data)
    return data
  } catch (err: any) {
    console.error("[v0] Transactions API Error:", err)
    return { success: false, error: err.message }
  }
}

async function callWithdrawAPI(msisdn: string, amount: number) {
  const url = `https://vjpilesug.okotstephen57.workers.dev/api/withdraw`

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        msisdn,
        amount,
        description: "DIMPOZ Admin Withdrawal",
      }),
    })

    return await response.json()
  } catch (err: any) {
    console.error("Withdraw API Error:", err)
    return { success: false, error: err.message }
  }
}

export default function WalletPage() {
  const { user, loading, isAdmin } = useAuth()
  const router = useRouter()
  const [balance, setBalance] = useState(0)
  const [transactions, setTransactions] = useState<any[]>([])
  const [withdrawAmount, setWithdrawAmount] = useState("")
  const [withdrawPhone, setWithdrawPhone] = useState("")
  const [processing, setProcessing] = useState(false)
  const [message, setMessage] = useState({ type: "", text: "" })
  const [loadingData, setLoadingData] = useState(true)
  const [editingBalance, setEditingBalance] = useState(false)
  const [editBalanceValue, setEditBalanceValue] = useState("")
  const [deletingTxId, setDeletingTxId] = useState<string | null>(null)
  const [isMasterAdmin, setIsMasterAdmin] = useState(false)

  useEffect(() => {
    if (!loading && (!user || !isAdmin)) {
      router.push("/login")
    }
  }, [user, loading, isAdmin, router])

  useEffect(() => {
    if (user?.email === "mainplatform.nexus@gmail.com") {
      setIsMasterAdmin(true)
    } else {
      setIsMasterAdmin(false)
    }
  }, [user])

  useEffect(() => {
    if (isAdmin) {
      loadWalletData()
    }
  }, [isAdmin])

  const loadWalletData = async () => {
    setLoadingData(true)
    try {
      // Fetch balance from API
      const balanceResponse = await fetchWalletBalance()
      if (balanceResponse.success && balanceResponse.balance !== undefined) {
        setBalance(balanceResponse.balance)
      } else {
        console.error("Failed to fetch balance:", balanceResponse.error)
        setBalance(0)
      }

      // Fetch transactions from API
      const transactionsResponse = await fetchTransactions()
      if (transactionsResponse.success && Array.isArray(transactionsResponse.transactions)) {
        const txArray = transactionsResponse.transactions.map((tx: any, index: number) => ({
          id: tx.id || `tx-${index}`,
          type: tx.type || "subscription",
          amount: tx.amount || 0,
          netAmount: tx.netAmount,
          fee: tx.fee,
          phoneNumber: tx.phoneNumber || tx.msisdn,
          reference: tx.reference || tx.internal_reference,
          timestamp: tx.timestamp || tx.created_at || new Date().toISOString(),
          planName: tx.planName || tx.description || "Subscription",
          userId: tx.userId || tx.user_id || "Unknown",
          userName: tx.userName || tx.user_name,
          source: tx.source,
          status: tx.status || "pending",
        }))

        // Sort by timestamp (most recent first)
        txArray.sort((a: any, b: any) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
        setTransactions(txArray)
      } else {
        console.error("Failed to fetch transactions:", transactionsResponse.error)
        setTransactions([])
      }
    } catch (error) {
      console.error("Error loading wallet data:", error)
      setBalance(0)
      setTransactions([])
    } finally {
      setLoadingData(false)
    }
  }

  const handleWithdraw = async (e: React.FormEvent) => {
    e.preventDefault()
    setProcessing(true)
    setMessage({ type: "", text: "" })

    try {
      const amount = Number.parseFloat(withdrawAmount)
      if (isNaN(amount) || amount <= 0) {
        throw new Error("Invalid amount")
      }

      if (amount > balance) {
        throw new Error("Insufficient balance")
      }

      const relworxFee = (amount / 1000) * 200
      const netAmount = amount - relworxFee

      // Format phone number
      let formattedPhone = withdrawPhone.trim()
      if (formattedPhone.startsWith("0")) {
        formattedPhone = "+256" + formattedPhone.substring(1)
      } else if (!formattedPhone.startsWith("+")) {
        formattedPhone = "+256" + formattedPhone
      }

      if (!formattedPhone.match(/^\+256[37]\d{8}$/)) {
        throw new Error("Please enter a valid Ugandan phone number")
      }

      // Call withdrawal API with net amount (after fee)
      const withdrawResult = await callWithdrawAPI(formattedPhone, netAmount)

      if (!withdrawResult.success) {
        throw new Error(withdrawResult.error || "Withdrawal failed")
      }

      setMessage({
        type: "success",
        text: `Withdrawal successful! UGX ${netAmount.toLocaleString()} sent to ${formattedPhone}. Relworx Fee: UGX ${relworxFee.toLocaleString()}`,
      })
      setWithdrawAmount("")
      setWithdrawPhone("")

      loadWalletData()
    } catch (err: any) {
      setMessage({ type: "error", text: err.message || "Withdrawal failed" })
    } finally {
      setProcessing(false)
    }
  }

  const handleEditBalance = async () => {
    setMessage({ type: "error", text: "Balance editing should be done through backend API" })
    setEditingBalance(false)
  }

  const handleDeleteTransaction = async (txId: string) => {
    setMessage({ type: "error", text: "Transaction deletion should be done through backend API" })
  }

  if (loading || loadingData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center">
        <div className="flex items-center gap-3 text-white text-xl">
          <Loader2 className="w-6 h-6 animate-spin" />
          <span>Loading...</span>
        </div>
      </div>
    )
  }

  if (!isAdmin) {
    return null
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Desktop sidebar */}
      <div className="hidden lg:block">
        <Sidebar onFilterChange={() => {}} activeFilter="settings" />
      </div>

      {/* Admin Navigation */}
      <AdminNav />
      <AdminMobileNav />

      {/* Main content with proper padding */}
      <main className="lg:ml-48 pt-14 pb-20 md:pb-6 px-3 md:px-6 min-h-screen">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-6">
            <h1 className="text-2xl md:text-3xl font-bold text-foreground">Wallet</h1>
            <p className="text-sm text-muted-foreground mt-1">Manage your earnings and withdrawals</p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 md:gap-4 mb-6">
            <Card className="bg-gradient-to-br from-cyan-500/20 to-purple-500/20 border border-cyan-500/30 p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="text-cyan-400 text-xs font-semibold">Available Balance</div>
                <DollarSign className="w-4 h-4 text-cyan-400" />
              </div>
              <div className="text-2xl md:text-3xl font-bold text-foreground">
                UGX {Math.max(0, balance || 0).toLocaleString()}
              </div>
            </Card>

            <Card className="bg-card border-border p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="text-muted-foreground text-xs font-semibold">Total Transactions</div>
                <TrendingUp className="w-4 h-4 text-green-400" />
              </div>
              <div className="text-2xl md:text-3xl font-bold text-foreground">{transactions.length}</div>
            </Card>

            <Card className="bg-card border-border p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="text-muted-foreground text-xs font-semibold">Total Earned</div>
                <TrendingUp className="w-4 h-4 text-purple-400" />
              </div>
              <div className="text-2xl md:text-3xl font-bold text-foreground">
                UGX{" "}
                {Math.max(
                  0,
                  transactions
                    .filter(
                      (tx) =>
                        tx.type === "subscription" &&
                        (tx.status === "successful" || tx.status === "success" || tx.status === "completed"),
                    )
                    .reduce((sum, tx) => sum + (tx.amount ?? 0), 0) || 0,
                ).toLocaleString()}
              </div>
            </Card>
          </div>

          {/* Two column layout for withdraw and transactions */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
            {/* Withdraw Form */}
            <Card className="bg-card border-border p-4 md:p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-gradient-to-br from-cyan-500 to-purple-600 rounded-lg">
                  <ArrowDownToLine className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-foreground">Withdraw Funds</h2>
                  <p className="text-muted-foreground text-xs">20% Relworx fee (200 UGX per 1000 UGX)</p>
                </div>
              </div>

              <form onSubmit={handleWithdraw} className="space-y-4">
                <div>
                  <label className="block text-foreground font-medium text-sm mb-2">Amount (UGX)</label>
                  <input
                    type="number"
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                    placeholder="Enter amount"
                    className="w-full px-4 py-3 bg-muted border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition"
                    required
                    min="1000"
                    max={balance}
                  />
                  {withdrawAmount && (
                    <p className="text-muted-foreground text-xs mt-1.5">
                      You will receive: UGX {(Number.parseFloat(withdrawAmount) * 0.8).toLocaleString()} (Fee: UGX{" "}
                      {(Number.parseFloat(withdrawAmount) * 0.2).toLocaleString()})
                    </p>
                  )}
                </div>

                <div>
                  <label className="block text-foreground font-medium text-sm mb-2">Phone Number</label>
                  <input
                    type="tel"
                    value={withdrawPhone}
                    onChange={(e) => setWithdrawPhone(e.target.value)}
                    placeholder="0771234567"
                    className="w-full px-4 py-3 bg-muted border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition"
                    required
                  />
                </div>

                {message.text && (
                  <div
                    className={`rounded-lg p-3 ${
                      message.type === "success"
                        ? "bg-green-500/10 border border-green-500/30"
                        : "bg-red-500/10 border border-red-500/30"
                    }`}
                  >
                    <p className={`text-sm ${message.type === "success" ? "text-green-500" : "text-red-500"}`}>
                      {message.text}
                    </p>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={processing || !withdrawAmount || !withdrawPhone || balance === 0}
                  className="w-full py-3 bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700 text-white rounded-lg font-bold transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {processing ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    "Withdraw Funds"
                  )}
                </button>
              </form>
            </Card>

            {/* Recent Transactions */}
            <Card className="bg-card border-border p-4 md:p-6">
              <h2 className="text-lg font-bold text-foreground mb-4">Recent Transactions</h2>
              <div className="space-y-2 max-h-[400px] overflow-y-auto">
                {transactions.slice(0, 10).map((tx) => {
                  const isSuccessful =
                    tx.status === "successful" || tx.status === "success" || tx.status === "completed"
                  const isFailed = tx.status === "failed" || tx.status === "failure" || tx.status === "cancelled"
                  const isPending = !isSuccessful && !isFailed

                  return (
                    <div
                      key={tx.id}
                      className={`p-3 rounded-lg border ${
                        isFailed
                          ? "bg-red-500/5 border-red-500/20"
                          : isPending
                            ? "bg-yellow-500/5 border-yellow-500/20"
                            : tx.type === "subscription"
                              ? "bg-green-500/5 border-green-500/20"
                              : tx.type === "withdrawal"
                                ? "bg-orange-500/5 border-orange-500/20"
                                : "bg-purple-500/5 border-purple-500/20"
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-2">
                          <span
                            className={`font-semibold text-sm ${
                              isFailed
                                ? "text-red-500"
                                : isPending
                                  ? "text-yellow-500"
                                  : tx.type === "subscription"
                                    ? "text-green-500"
                                    : tx.type === "withdrawal"
                                      ? "text-orange-500"
                                      : "text-purple-500"
                            }`}
                          >
                            {tx.type === "subscription"
                              ? `+UGX ${(tx.amount ?? 0).toLocaleString()}`
                              : tx.type === "withdrawal"
                                ? `-UGX ${(tx.amount ?? 0).toLocaleString()}`
                                : `+UGX ${(tx.amount ?? 0).toLocaleString()}`}
                          </span>
                          <span
                            className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${
                              isFailed
                                ? "bg-red-500/20 text-red-500"
                                : isPending
                                  ? "bg-yellow-500/20 text-yellow-500"
                                  : "bg-green-500/20 text-green-500"
                            }`}
                          >
                            {isFailed ? "Failed" : isPending ? "Pending" : "Successful"}
                          </span>
                        </div>
                        <span className="text-muted-foreground text-xs">
                          {new Date(tx.timestamp).toLocaleDateString()}
                        </span>
                      </div>
                      <div className="text-muted-foreground text-xs">
                        {tx.type === "subscription" && (
                          <>
                            {tx.planName || "Subscription"} {tx.phoneNumber && `- ${tx.phoneNumber}`}
                          </>
                        )}
                        {tx.type === "withdrawal" && (
                          <>
                            Withdrawn to {tx.phoneNumber || "N/A"}{" "}
                            {tx.netAmount && `(Net: UGX ${(tx.netAmount ?? 0).toLocaleString()})`}
                          </>
                        )}
                        {tx.type === "fee" && "Relworx Withdrawal Fee (20%)"}
                        {tx.type !== "subscription" && tx.type !== "withdrawal" && tx.type !== "fee" && (
                          <>
                            {tx.planName || tx.type || "Transaction"} {tx.phoneNumber && `- ${tx.phoneNumber}`}
                          </>
                        )}
                      </div>
                      {tx.reference && (
                        <div className="text-muted-foreground/60 text-[10px] mt-1">Ref: {tx.reference}</div>
                      )}
                    </div>
                  )
                })}
                {transactions.length === 0 && (
                  <div className="text-muted-foreground text-center py-8">No transactions yet</div>
                )}
              </div>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
