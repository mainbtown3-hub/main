"use client"

import type React from "react"
import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import Sidebar from "@/components/sidebar"
import AdminNav from "@/components/admin-nav"
import AdminMobileNav from "@/components/admin-mobile-nav"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { database } from "@/lib/firebase"
import { ref as dbRef, push, get, remove } from "firebase/database"
import { Trash2 } from "lucide-react"

interface CarouselItem {
  id: string
  title: string
  subtitle: string
  image: string
  contentType?: string
  contentId?: string
}

interface Content {
  id: string
  title: string
}

export default function CarouselManagement() {
  const { user, loading, isAdmin } = useAuth()
  const router = useRouter()
  const [items, setItems] = useState<CarouselItem[]>([])
  const [movies, setMovies] = useState<Content[]>([])
  const [series, setSeries] = useState<Content[]>([])
  const [newItem, setNewItem] = useState({
    title: "",
    subtitle: "",
    image: "",
    contentType: "",
    contentId: "",
  })
  const [uploading, setUploading] = useState(false)
  const [successMessage, setSuccessMessage] = useState("")

  useEffect(() => {
    if (!loading && (!user || !isAdmin)) {
      router.push("/login")
    }
  }, [user, loading, isAdmin, router])

  useEffect(() => {
    if (isAdmin) {
      loadCarousel()
      loadMovies()
      loadSeries()
    }
  }, [isAdmin])

  const loadCarousel = async () => {
    try {
      const carouselRef = dbRef(database, "carousel")
      const snapshot = await get(carouselRef)
      if (snapshot.exists()) {
        const data = snapshot.val()
        const itemsList = Object.entries(data).map(([id, value]: any) => ({
          id,
          ...value,
        }))
        setItems(itemsList)
      }
    } catch (error) {
      console.error("Error loading carousel:", error)
    }
  }

  const loadMovies = async () => {
    try {
      const moviesRef = dbRef(database, "movies")
      const snapshot = await get(moviesRef)
      if (snapshot.exists()) {
        const data = snapshot.val()
        const moviesList = Object.entries(data).map(([id, value]: any) => ({
          id,
          title: value.title,
        }))
        setMovies(moviesList)
      }
    } catch (error) {
      console.error("Error loading movies:", error)
    }
  }

  const loadSeries = async () => {
    try {
      const seriesRef = dbRef(database, "series")
      const snapshot = await get(seriesRef)
      if (snapshot.exists()) {
        const data = snapshot.val()
        const seriesList = Object.entries(data).map(([id, value]: any) => ({
          id,
          title: value.title,
        }))
        setSeries(seriesList)
      }
    } catch (error) {
      console.error("Error loading series:", error)
    }
  }

  const handleAddItem = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!newItem.image.trim()) {
      alert("Please enter an image URL")
      return
    }

    if (!newItem.title.trim()) {
      alert("Please enter a title")
      return
    }

    if (newItem.contentType && !newItem.contentId) {
      alert("Please select a content item to link")
      return
    }

    setUploading(true)
    try {
      const carouselRef = dbRef(database, "carousel")
      await push(carouselRef, {
        title: newItem.title,
        subtitle: newItem.subtitle,
        image: newItem.image,
        contentType: newItem.contentType || null,
        contentId: newItem.contentId || null,
        createdAt: new Date().toISOString(),
      })

      setSuccessMessage("Carousel item added successfully!")
      setTimeout(() => setSuccessMessage(""), 3000)
      setNewItem({
        title: "",
        subtitle: "",
        image: "",
        contentType: "",
        contentId: "",
      })
      loadCarousel()
    } catch (error) {
      console.error("Error adding carousel item:", error)
      alert("Error adding carousel item")
    } finally {
      setUploading(false)
    }
  }

  const handleDeleteItem = async (id: string) => {
    if (confirm("Are you sure you want to delete this carousel item?")) {
      try {
        await remove(dbRef(database, `carousel/${id}`))
        setSuccessMessage("Carousel item deleted successfully!")
        setTimeout(() => setSuccessMessage(""), 3000)
        loadCarousel()
      } catch (error) {
        console.error("Error deleting item:", error)
      }
    }
  }

  const getAvailableContent = () => {
    if (newItem.contentType === "movie") return movies
    if (newItem.contentType === "series") return series
    return []
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-foreground text-xl">Loading...</div>
      </div>
    )
  }

  if (!isAdmin) {
    return null
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Desktop sidebar */}
      <div className="hidden lg:block">
        <Sidebar onFilterChange={() => {}} activeFilter="settings" />
      </div>

      {/* Admin Navigation */}
      <AdminNav />
      <AdminMobileNav />

      {/* Main content with proper padding */}
      <main className="lg:ml-48 pt-14 pb-20 md:pb-6 px-3 md:px-6 min-h-screen">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-6">
            <h1 className="text-2xl md:text-3xl font-bold text-foreground">Manage Carousel</h1>
            <p className="text-sm text-muted-foreground mt-1">Total: {items.length} items</p>
          </div>

          {successMessage && (
            <div className="mb-4 p-3 bg-green-500/20 border border-green-500/30 rounded text-green-500 text-sm">
              {successMessage}
            </div>
          )}

          {/* Add Form */}
          <Card className="bg-card border-border p-4 md:p-6 mb-6">
            <h2 className="text-lg font-bold text-foreground mb-4">Add Carousel Item</h2>
            <form onSubmit={handleAddItem} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Title *</label>
                  <Input
                    value={newItem.title}
                    onChange={(e) => setNewItem({ ...newItem, title: e.target.value })}
                    className="bg-muted border-border text-foreground"
                    placeholder="Enter title"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Subtitle</label>
                  <Input
                    value={newItem.subtitle}
                    onChange={(e) => setNewItem({ ...newItem, subtitle: e.target.value })}
                    className="bg-muted border-border text-foreground"
                    placeholder="Enter subtitle"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-foreground mb-1.5">Banner Image URL *</label>
                  <Input
                    type="url"
                    value={newItem.image}
                    onChange={(e) => setNewItem({ ...newItem, image: e.target.value })}
                    className="bg-muted border-border text-foreground"
                    placeholder="https://example.com/image.jpg"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Link to Content (Optional)</label>
                  <select
                    value={newItem.contentType}
                    onChange={(e) => setNewItem({ ...newItem, contentType: e.target.value, contentId: "" })}
                    className="w-full bg-muted border border-border text-foreground rounded-md px-3 py-2 text-sm"
                  >
                    <option value="">No Link</option>
                    <option value="movie">Movie</option>
                    <option value="series">Series</option>
                  </select>
                </div>

                {newItem.contentType && (
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-1.5">
                      Select {newItem.contentType === "movie" ? "Movie" : "Series"} *
                    </label>
                    <select
                      value={newItem.contentId}
                      onChange={(e) => setNewItem({ ...newItem, contentId: e.target.value })}
                      className="w-full bg-muted border border-border text-foreground rounded-md px-3 py-2 text-sm"
                      required
                    >
                      <option value="">Select...</option>
                      {getAvailableContent().map((content) => (
                        <option key={content.id} value={content.id}>
                          {content.title}
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>

              <Button
                type="submit"
                disabled={uploading}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                {uploading ? "Adding..." : "Add Item"}
              </Button>
            </form>
          </Card>

          {/* Carousel Items List */}
          <div className="space-y-3">
            {items.map((item) => (
              <Card key={item.id} className="bg-card border-border p-3 hover:border-primary/30 transition">
                <div className="flex gap-3">
                  <div className="w-24 h-16 md:w-32 md:h-20 bg-muted rounded overflow-hidden flex-shrink-0">
                    <img
                      src={item.image || "/placeholder.svg"}
                      alt={item.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-foreground truncate">{item.title}</h3>
                    <p className="text-muted-foreground text-sm truncate">{item.subtitle}</p>
                    {item.contentType && item.contentId && (
                      <p className="text-primary text-xs mt-1">
                        Linked to: {item.contentType === "movie" ? "Movie" : "Series"}
                      </p>
                    )}
                  </div>
                  <Button
                    onClick={() => handleDeleteItem(item.id)}
                    variant="destructive"
                    size="sm"
                    className="flex-shrink-0"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
