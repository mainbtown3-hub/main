"use client"

import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import Sidebar from "@/components/sidebar"
import AdminNav from "@/components/admin-nav"
import AdminMobileNav from "@/components/admin-mobile-nav"
import { Card } from "@/components/ui/card"
import { database } from "@/lib/firebase"
import { ref as dbRef, get } from "firebase/database"
import { Users, Calendar, Mail, CheckCircle, XCircle, Clock } from "lucide-react"
import { SUBSCRIPTION_PLANS } from "@/lib/subscription-context"

interface Subscription {
  planId: string
  startDate: string
  endDate: string
  active: boolean
}

interface User {
  id: string
  email: string
  displayName?: string
  photoURL?: string
  createdAt: string
  lastLogin?: string
  subscription?: Subscription
}

const calculateRemainingTime = (endDate: string) => {
  const now = new Date()
  const expiry = new Date(endDate)
  const diff = expiry.getTime() - now.getTime()

  if (diff <= 0) return "Expired"

  const days = Math.floor(diff / (1000 * 60 * 60 * 24))
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))

  if (days > 0) {
    return `${days}d ${hours}h`
  } else if (hours > 0) {
    return `${hours}h ${minutes}m`
  } else {
    return `${minutes}m`
  }
}

const getPlanName = (planId: string) => {
  const plan = SUBSCRIPTION_PLANS.find((p) => p.id === planId)
  return plan ? plan.name : planId
}

export default function UsersManagement() {
  const { user, loading, isAdmin } = useAuth()
  const router = useRouter()
  const [users, setUsers] = useState<User[]>([])
  const [usersLoading, setUsersLoading] = useState(true)

  useEffect(() => {
    if (!loading && (!user || !isAdmin)) {
      router.push("/login")
    }
  }, [user, loading, isAdmin, router])

  useEffect(() => {
    if (isAdmin) {
      loadUsers()
    }
  }, [isAdmin])

  const loadUsers = async () => {
    try {
      const [usersSnap, subscriptionsSnap] = await Promise.all([
        get(dbRef(database, "users")),
        get(dbRef(database, "subscriptions")),
      ])

      if (usersSnap.exists()) {
        const usersData = usersSnap.val()
        const subscriptionsData = subscriptionsSnap.exists() ? subscriptionsSnap.val() : {}

        const usersList = Object.entries(usersData).map(([id, value]: any) => {
          const userSubscription = subscriptionsData[id]

          return {
            id,
            email: value.email || "N/A",
            displayName: value.displayName || "User",
            photoURL: value.photoURL,
            createdAt: value.createdAt || new Date().toISOString(),
            lastLogin: value.lastLogin,
            subscription: userSubscription || undefined,
          }
        })

        // Sort by last login (most recent first)
        usersList.sort((a, b) => {
          const dateA = new Date(a.lastLogin || a.createdAt).getTime()
          const dateB = new Date(b.lastLogin || b.createdAt).getTime()
          return dateB - dateA
        })

        setUsers(usersList)
      }
      setUsersLoading(false)
    } catch (error) {
      console.error("Error loading users:", error)
      setUsersLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-foreground text-xl">Loading...</div>
      </div>
    )
  }

  if (!isAdmin) {
    return null
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Desktop sidebar */}
      <div className="hidden lg:block">
        <Sidebar onFilterChange={() => {}} activeFilter="settings" />
      </div>

      {/* Admin Navigation */}
      <AdminNav />
      <AdminMobileNav />

      {/* Main content with proper padding */}
      <main className="lg:ml-48 pt-14 pb-20 md:pb-6 px-3 md:px-6 min-h-screen">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-6">
            <h1 className="text-2xl md:text-3xl font-bold text-foreground">Manage Users</h1>
            <p className="text-sm text-muted-foreground mt-1">Total Users: {users.length}</p>
          </div>

          {usersLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="text-foreground">Loading users...</div>
            </div>
          ) : users.length === 0 ? (
            <Card className="bg-card border-border p-8">
              <div className="text-center">
                <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No users registered yet</p>
              </div>
            </Card>
          ) : (
            <div className="grid grid-cols-1 gap-3">
              {users.map((userItem) => (
                <Card key={userItem.id} className="bg-card border-border p-4 hover:border-primary/30 transition">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-3 mb-3">
                        {userItem.photoURL ? (
                          <img
                            src={userItem.photoURL || "/placeholder.svg"}
                            alt={userItem.displayName}
                            className="w-10 h-10 rounded-full object-cover flex-shrink-0"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                            <span className="text-primary font-bold">
                              {userItem.displayName?.charAt(0) || userItem.email?.charAt(0) || "U"}
                            </span>
                          </div>
                        )}
                        <div className="min-w-0">
                          <h3 className="font-semibold text-foreground truncate">{userItem.displayName}</h3>
                          <div className="flex items-center gap-1 text-muted-foreground text-xs">
                            <Mail className="w-3 h-3 flex-shrink-0" />
                            <span className="truncate">{userItem.email}</span>
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3 text-xs">
                        <div>
                          <p className="text-muted-foreground">Created</p>
                          <p className="text-foreground flex items-center gap-1 mt-0.5">
                            <Calendar className="w-3 h-3" />
                            {new Date(userItem.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Last Login</p>
                          <p className="text-foreground flex items-center gap-1 mt-0.5">
                            <Calendar className="w-3 h-3" />
                            {userItem.lastLogin ? new Date(userItem.lastLogin).toLocaleDateString() : "Never"}
                          </p>
                        </div>
                      </div>

                      {userItem.subscription && (
                        <div className="mt-3 p-3 bg-muted/50 rounded-lg">
                          <p className="text-muted-foreground text-[10px] uppercase tracking-wider mb-2">
                            Subscription
                          </p>
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                            <div>
                              <p className="text-muted-foreground">Plan</p>
                              <p className="text-foreground font-medium">{getPlanName(userItem.subscription.planId)}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground">Start</p>
                              <p className="text-foreground">
                                {new Date(userItem.subscription.startDate).toLocaleDateString()}
                              </p>
                            </div>
                            <div>
                              <p className="text-muted-foreground">Expires</p>
                              <p className="text-foreground">
                                {new Date(userItem.subscription.endDate).toLocaleDateString()}
                              </p>
                            </div>
                            <div>
                              <p className="text-muted-foreground flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                Remaining
                              </p>
                              <p className="text-foreground font-medium">
                                {calculateRemainingTime(userItem.subscription.endDate)}
                              </p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="flex-shrink-0">
                      {userItem.subscription?.active && new Date(userItem.subscription.endDate) > new Date() ? (
                        <span className="inline-flex items-center gap-1 px-2 py-1 bg-green-500/10 border border-green-500/30 rounded text-green-500 text-[10px] font-medium">
                          <CheckCircle className="w-3 h-3" />
                          Active
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-1 bg-red-500/10 border border-red-500/30 rounded text-red-500 text-[10px] font-medium">
                          <XCircle className="w-3 h-3" />
                          {userItem.subscription ? "Expired" : "None"}
                        </span>
                      )}
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
