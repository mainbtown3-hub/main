import type React from "react"
import type { Metadata, Viewport } from "next"

export const metadata: Metadata = {
  title: "Admin Panel - VJ PILES UG Movies",
  description: "Admin dashboard for managing content and users",
}

export const viewport: Viewport = {
  themeColor: "#0f172a",
}

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}
