"use client"

import type React from "react"
import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import Sidebar from "@/components/sidebar"
import AdminNav from "@/components/admin-nav"
import AdminMobileNav from "@/components/admin-mobile-nav"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { database } from "@/lib/firebase"
import { ref as dbRef, push, get, remove, update } from "firebase/database"
import { Star, Trash2, Edit } from "lucide-react"

interface Animation {
  id: string
  title: string
  image: string
  rating: number
  year: number
  genre: string
  streamlink: string
  type: string
}

const GENRES = ["Action", "Adventure", "Comedy", "Drama", "Fantasy", "Sci-Fi", "Romance", "Thriller"]

export default function AnimationManagement() {
  const { user, loading, isAdmin } = useAuth()
  const router = useRouter()
  const [animations, setAnimations] = useState<Animation[]>([])
  const [newAnimation, setNewAnimation] = useState({
    title: "",
    image: "",
    rating: 7.5,
    year: new Date().getFullYear(),
    genre: "Action",
    streamlink: "",
    type: "anime",
  })
  const [uploading, setUploading] = useState(false)
  const [successMessage, setSuccessMessage] = useState("")
  const [editingAnimation, setEditingAnimation] = useState<Animation | null>(null)

  useEffect(() => {
    if (!loading && (!user || !isAdmin)) {
      router.push("/login")
    }
  }, [user, loading, isAdmin, router])

  useEffect(() => {
    if (isAdmin) {
      loadAnimations()
    }
  }, [isAdmin])

  const loadAnimations = async () => {
    try {
      const moviesRef = dbRef(database, "movies")
      const snapshot = await get(moviesRef)
      if (snapshot.exists()) {
        const data = snapshot.val()
        const animationsList = Object.entries(data)
          .map(([id, value]: any) => ({
            id,
            ...value,
          }))
          .filter((item: any) => item.category?.toLowerCase() === "animation")
        setAnimations(animationsList)
      }
    } catch (error) {
      console.error("Error loading animations:", error)
    }
  }

  const handleAddAnimation = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!newAnimation.image.trim() || !newAnimation.title.trim() || !newAnimation.streamlink.trim()) {
      alert("Please fill in all required fields")
      return
    }

    setUploading(true)
    try {
      const moviesRef = dbRef(database, "movies")
      await push(moviesRef, {
        title: newAnimation.title,
        image: newAnimation.image,
        rating: Number.parseFloat(newAnimation.rating.toString()),
        year: newAnimation.year,
        category: "Animation",
        genre: newAnimation.genre,
        streamlink: newAnimation.streamlink,
        type: newAnimation.type,
        createdAt: new Date().toISOString(),
      })

      setSuccessMessage("Animation added successfully!")
      setTimeout(() => setSuccessMessage(""), 3000)
      setNewAnimation({
        title: "",
        image: "",
        rating: 7.5,
        year: new Date().getFullYear(),
        genre: "Action",
        streamlink: "",
        type: "anime",
      })
      loadAnimations()
    } catch (error) {
      console.error("Error adding animation:", error)
      alert("Error adding animation. Please try again.")
    } finally {
      setUploading(false)
    }
  }

  const handleEditAnimation = (animation: Animation) => {
    setEditingAnimation(animation)
    setNewAnimation({
      title: animation.title,
      image: animation.image,
      rating: animation.rating,
      year: animation.year,
      genre: animation.genre,
      streamlink: animation.streamlink,
      type: animation.type,
    })
  }

  const handleUpdateAnimation = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!editingAnimation) return

    if (!newAnimation.image.trim() || !newAnimation.title.trim() || !newAnimation.streamlink.trim()) {
      alert("Please fill in all required fields")
      return
    }

    setUploading(true)
    try {
      await update(dbRef(database, `movies/${editingAnimation.id}`), {
        title: newAnimation.title,
        image: newAnimation.image,
        rating: Number.parseFloat(newAnimation.rating.toString()),
        year: newAnimation.year,
        category: "Animation",
        genre: newAnimation.genre,
        streamlink: newAnimation.streamlink,
        type: newAnimation.type,
        updatedAt: new Date().toISOString(),
      })

      setSuccessMessage("Animation updated successfully!")
      setTimeout(() => setSuccessMessage(""), 3000)
      setEditingAnimation(null)
      setNewAnimation({
        title: "",
        image: "",
        rating: 7.5,
        year: new Date().getFullYear(),
        genre: "Action",
        streamlink: "",
        type: "anime",
      })
      loadAnimations()
    } catch (error) {
      console.error("Error updating animation:", error)
      alert("Error updating animation. Please try again.")
    } finally {
      setUploading(false)
    }
  }

  const handleCancelEdit = () => {
    setEditingAnimation(null)
    setNewAnimation({
      title: "",
      image: "",
      rating: 7.5,
      year: new Date().getFullYear(),
      genre: "Action",
      streamlink: "",
      type: "anime",
    })
  }

  const handleDeleteAnimation = async (id: string) => {
    if (confirm("Are you sure you want to delete this animation?")) {
      try {
        await remove(dbRef(database, `movies/${id}`))
        setSuccessMessage("Animation deleted successfully!")
        setTimeout(() => setSuccessMessage(""), 3000)
        loadAnimations()
      } catch (error) {
        console.error("Error deleting animation:", error)
      }
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-foreground text-xl">Loading...</div>
      </div>
    )
  }

  if (!isAdmin) {
    return null
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Desktop sidebar */}
      <div className="hidden lg:block">
        <Sidebar onFilterChange={() => {}} activeFilter="settings" />
      </div>

      {/* Admin Navigation */}
      <AdminNav />
      <AdminMobileNav />

      {/* Main content with proper padding */}
      <main className="lg:ml-48 pt-14 pb-20 md:pb-6 px-3 md:px-6 min-h-screen">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-6">
            <h1 className="text-2xl md:text-3xl font-bold text-foreground">Manage Animations</h1>
            <p className="text-sm text-muted-foreground mt-1">Total: {animations.length} animations</p>
          </div>

          {successMessage && (
            <div className="mb-4 p-3 bg-green-500/20 border border-green-500/30 rounded text-green-500 text-sm">
              {successMessage}
            </div>
          )}

          {/* Add/Edit Form */}
          <Card className="bg-card border-border p-4 md:p-6 mb-6">
            <h2 className="text-lg font-bold text-foreground mb-4">
              {editingAnimation ? "Edit Animation" : "Add New Animation"}
            </h2>
            <form onSubmit={editingAnimation ? handleUpdateAnimation : handleAddAnimation} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Title *</label>
                  <Input
                    value={newAnimation.title}
                    onChange={(e) => setNewAnimation({ ...newAnimation, title: e.target.value })}
                    className="bg-muted border-border text-foreground"
                    placeholder="Enter animation title"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Genre *</label>
                  <select
                    value={newAnimation.genre}
                    onChange={(e) => setNewAnimation({ ...newAnimation, genre: e.target.value })}
                    className="w-full bg-muted border border-border text-foreground rounded-md px-3 py-2 text-sm"
                    required
                  >
                    {GENRES.map((genre) => (
                      <option key={genre} value={genre}>
                        {genre}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Stream Link *</label>
                  <Input
                    type="url"
                    value={newAnimation.streamlink}
                    onChange={(e) => setNewAnimation({ ...newAnimation, streamlink: e.target.value })}
                    className="bg-muted border-border text-foreground"
                    placeholder="https://example.com/stream/anime.mp4"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Rating (0-10)</label>
                  <Input
                    type="number"
                    min="0"
                    max="10"
                    step="0.1"
                    value={newAnimation.rating}
                    onChange={(e) => setNewAnimation({ ...newAnimation, rating: Number.parseFloat(e.target.value) })}
                    className="bg-muted border-border text-foreground"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Year</label>
                  <Input
                    type="number"
                    value={newAnimation.year}
                    onChange={(e) => setNewAnimation({ ...newAnimation, year: Number.parseInt(e.target.value) })}
                    className="bg-muted border-border text-foreground"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Poster Image URL *</label>
                  <Input
                    type="url"
                    value={newAnimation.image}
                    onChange={(e) => setNewAnimation({ ...newAnimation, image: e.target.value })}
                    className="bg-muted border-border text-foreground"
                    placeholder="https://example.com/image.jpg"
                    required
                  />
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  type="submit"
                  disabled={uploading}
                  className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  {uploading
                    ? editingAnimation
                      ? "Updating..."
                      : "Adding..."
                    : editingAnimation
                      ? "Update Animation"
                      : "Add Animation"}
                </Button>
                {editingAnimation && (
                  <Button
                    type="button"
                    onClick={handleCancelEdit}
                    variant="outline"
                    className="border-border bg-transparent"
                  >
                    Cancel
                  </Button>
                )}
              </div>
            </form>
          </Card>

          {/* Animations Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 md:gap-4">
            {animations.map((animation) => (
              <Card
                key={animation.id}
                className="bg-card border-border overflow-hidden hover:border-primary/50 transition"
              >
                <div className="relative aspect-[2/3] bg-muted">
                  <img
                    src={animation.image || "/placeholder.svg"}
                    alt={animation.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-2.5">
                  <h3 className="font-semibold text-foreground text-sm mb-1 truncate">{animation.title}</h3>
                  <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
                    <span>{animation.genre}</span>
                    <span className="text-yellow-500 flex items-center gap-0.5">
                      <Star className="w-3 h-3 fill-yellow-500" />
                      {animation.rating}
                    </span>
                  </div>
                  <div className="space-y-1.5">
                    <Button
                      onClick={() => handleEditAnimation(animation)}
                      size="sm"
                      className="w-full h-7 text-xs bg-green-600 hover:bg-green-700 text-white"
                    >
                      <Edit className="w-3 h-3 mr-1" />
                      Edit
                    </Button>
                    <Button
                      onClick={() => handleDeleteAnimation(animation.id)}
                      variant="destructive"
                      size="sm"
                      className="w-full h-7 text-xs"
                    >
                      <Trash2 className="w-3 h-3 mr-1" />
                      Delete
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
