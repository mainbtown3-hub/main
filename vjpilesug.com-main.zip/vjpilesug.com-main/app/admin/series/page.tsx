"use client"

import type React from "react"
import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import Sidebar from "@/components/sidebar"
import AdminNav from "@/components/admin-nav"
import AdminMobileNav from "@/components/admin-mobile-nav"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { database } from "@/lib/firebase"
import { ref as dbRef, push, get, remove, update } from "firebase/database"
import { Star, Trash2, Plus, Edit } from "lucide-react"

interface Series {
  id: string
  title: string
  image: string
  rating: number
  year: number
  category: string
  episodes: Episode[]
}

interface Episode {
  episodeNumber: number
  title: string
  streamlink: string
}

const CATEGORIES = ["Action", "Romance", "Animation", "Horror", "Special", "Drabor", "Comedy", "Drama"]

export default function SeriesManagement() {
  const { user, loading, isAdmin } = useAuth()
  const router = useRouter()
  const [series, setSeries] = useState<Series[]>([])
  const [newSeries, setNewSeries] = useState({
    title: "",
    image: "",
    rating: 7.5,
    year: new Date().getFullYear(),
    category: "Animation",
    episodes: [{ episodeNumber: 1, title: "", streamlink: "" }],
  })
  const [uploading, setUploading] = useState(false)
  const [successMessage, setSuccessMessage] = useState("")
  const [editingSeries, setEditingSeries] = useState<Series | null>(null)

  useEffect(() => {
    if (!loading && (!user || !isAdmin)) {
      router.push("/login")
    }
  }, [user, loading, isAdmin, router])

  useEffect(() => {
    if (isAdmin) {
      loadSeries()
    }
  }, [isAdmin])

  const loadSeries = async () => {
    try {
      const seriesRef = dbRef(database, "series")
      const snapshot = await get(seriesRef)
      if (snapshot.exists()) {
        const data = snapshot.val()
        const seriesList = Object.entries(data).map(([id, value]: any) => ({
          id,
          ...value,
        }))
        setSeries(seriesList)
      }
    } catch (error) {
      console.error("Error loading series:", error)
    }
  }

  const handleAddEpisode = () => {
    setNewSeries({
      ...newSeries,
      episodes: [
        ...newSeries.episodes,
        {
          episodeNumber: newSeries.episodes.length + 1,
          title: "",
          streamlink: "",
        },
      ],
    })
  }

  const handleRemoveEpisode = (index: number) => {
    setNewSeries({
      ...newSeries,
      episodes: newSeries.episodes.filter((_, i) => i !== index),
    })
  }

  const handleEpisodeChange = (index: number, field: string, value: string) => {
    const updatedEpisodes = [...newSeries.episodes]
    updatedEpisodes[index] = { ...updatedEpisodes[index], [field]: value }
    setNewSeries({ ...newSeries, episodes: updatedEpisodes })
  }

  const handleAddSeries = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!newSeries.title.trim() || !newSeries.image.trim()) {
      alert("Please fill in all required fields")
      return
    }

    if (newSeries.episodes.some((ep) => !ep.title.trim() || !ep.streamlink.trim())) {
      alert("Please fill in all episode details")
      return
    }

    setUploading(true)
    try {
      const seriesRef = dbRef(database, "series")
      await push(seriesRef, {
        title: newSeries.title,
        image: newSeries.image,
        rating: Number.parseFloat(newSeries.rating.toString()),
        year: newSeries.year,
        category: newSeries.category,
        episodes: newSeries.episodes,
        createdAt: new Date().toISOString(),
      })

      setSuccessMessage("Series added successfully!")
      setTimeout(() => setSuccessMessage(""), 3000)
      setNewSeries({
        title: "",
        image: "",
        rating: 7.5,
        year: new Date().getFullYear(),
        category: "Animation",
        episodes: [{ episodeNumber: 1, title: "", streamlink: "" }],
      })
      loadSeries()
    } catch (error) {
      console.error("Error adding series:", error)
      alert("Error adding series. Please try again.")
    } finally {
      setUploading(false)
    }
  }

  const handleUpdateSeries = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!editingSeries) return

    if (!newSeries.title.trim() || !newSeries.image.trim()) {
      alert("Please fill in all required fields")
      return
    }

    if (newSeries.episodes.some((ep) => !ep.title.trim() || !ep.streamlink.trim())) {
      alert("Please fill in all episode details")
      return
    }

    setUploading(true)
    try {
      await update(dbRef(database, `series/${editingSeries.id}`), {
        title: newSeries.title,
        image: newSeries.image,
        rating: Number.parseFloat(newSeries.rating.toString()),
        year: newSeries.year,
        category: newSeries.category,
        episodes: newSeries.episodes,
        updatedAt: new Date().toISOString(),
      })

      setSuccessMessage("Series updated successfully!")
      setTimeout(() => setSuccessMessage(""), 3000)
      setEditingSeries(null)
      setNewSeries({
        title: "",
        image: "",
        rating: 7.5,
        year: new Date().getFullYear(),
        category: "Animation",
        episodes: [{ episodeNumber: 1, title: "", streamlink: "" }],
      })
      loadSeries()
    } catch (error) {
      console.error("Error updating series:", error)
      alert("Error updating series. Please try again.")
    } finally {
      setUploading(false)
    }
  }

  const handleEditSeries = (series: Series) => {
    setEditingSeries(series)
    setNewSeries({
      title: series.title,
      image: series.image,
      rating: series.rating,
      year: series.year,
      category: series.category,
      episodes: series.episodes,
    })
  }

  const handleCancelEdit = () => {
    setEditingSeries(null)
    setNewSeries({
      title: "",
      image: "",
      rating: 7.5,
      year: new Date().getFullYear(),
      category: "Animation",
      episodes: [{ episodeNumber: 1, title: "", streamlink: "" }],
    })
  }

  const handleDeleteSeries = async (id: string) => {
    if (confirm("Are you sure you want to delete this series?")) {
      try {
        await remove(dbRef(database, `series/${id}`))
        setSuccessMessage("Series deleted successfully!")
        setTimeout(() => setSuccessMessage(""), 3000)
        loadSeries()
      } catch (error) {
        console.error("Error deleting series:", error)
      }
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-foreground text-xl">Loading...</div>
      </div>
    )
  }

  if (!isAdmin) {
    return null
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Desktop sidebar */}
      <div className="hidden lg:block">
        <Sidebar onFilterChange={() => {}} activeFilter="settings" />
      </div>

      {/* Admin Navigation */}
      <AdminNav />
      <AdminMobileNav />

      {/* Main content with proper padding */}
      <main className="lg:ml-48 pt-14 pb-20 md:pb-6 px-3 md:px-6 min-h-screen">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-6">
            <h1 className="text-2xl md:text-3xl font-bold text-foreground">Manage Series</h1>
            <p className="text-sm text-muted-foreground mt-1">Total: {series.length} series</p>
          </div>

          {successMessage && (
            <div className="mb-4 p-3 bg-green-500/20 border border-green-500/30 rounded text-green-500 text-sm">
              {successMessage}
            </div>
          )}

          {/* Add/Edit Form */}
          <Card className="bg-card border-border p-4 md:p-6 mb-6">
            <h2 className="text-lg font-bold text-foreground mb-4">
              {editingSeries ? "Edit Series" : "Add New Series"}
            </h2>
            <form onSubmit={editingSeries ? handleUpdateSeries : handleAddSeries} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Series Title *</label>
                  <Input
                    value={newSeries.title}
                    onChange={(e) => setNewSeries({ ...newSeries, title: e.target.value })}
                    className="bg-muted border-border text-foreground"
                    placeholder="Enter series title"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Category *</label>
                  <select
                    value={newSeries.category}
                    onChange={(e) => setNewSeries({ ...newSeries, category: e.target.value })}
                    className="w-full bg-muted border border-border text-foreground rounded-md px-3 py-2 text-sm"
                    required
                  >
                    {CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Poster Image URL *</label>
                  <Input
                    type="url"
                    value={newSeries.image}
                    onChange={(e) => setNewSeries({ ...newSeries, image: e.target.value })}
                    className="bg-muted border-border text-foreground"
                    placeholder="https://example.com/image.jpg"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Rating (0-10)</label>
                  <Input
                    type="number"
                    min="0"
                    max="10"
                    step="0.1"
                    value={newSeries.rating}
                    onChange={(e) => setNewSeries({ ...newSeries, rating: Number.parseFloat(e.target.value) })}
                    className="bg-muted border-border text-foreground"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Year</label>
                  <Input
                    type="number"
                    value={newSeries.year}
                    onChange={(e) => setNewSeries({ ...newSeries, year: Number.parseInt(e.target.value) })}
                    className="bg-muted border-border text-foreground"
                  />
                </div>
              </div>

              {/* Episodes */}
              <div className="border-t border-border pt-4 mt-4">
                <h3 className="text-sm font-bold text-foreground mb-3">Episodes</h3>
                <div className="space-y-3">
                  {newSeries.episodes.map((episode, index) => (
                    <div key={index} className="bg-muted/50 p-3 rounded border border-border">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-foreground text-sm font-medium">Episode {episode.episodeNumber}</span>
                        {newSeries.episodes.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemoveEpisode(index)}
                            className="text-red-500 hover:text-red-400 text-xs"
                          >
                            Remove
                          </button>
                        )}
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        <Input
                          value={episode.title}
                          onChange={(e) => handleEpisodeChange(index, "title", e.target.value)}
                          className="bg-background border-border text-foreground text-sm"
                          placeholder="Episode title"
                          required
                        />
                        <Input
                          type="url"
                          value={episode.streamlink}
                          onChange={(e) => handleEpisodeChange(index, "streamlink", e.target.value)}
                          className="bg-background border-border text-foreground text-sm"
                          placeholder="Stream link URL"
                          required
                        />
                      </div>
                    </div>
                  ))}
                </div>
                <Button
                  type="button"
                  onClick={handleAddEpisode}
                  className="w-full mt-3 bg-green-600 hover:bg-green-700 text-white"
                  size="sm"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Add Episode
                </Button>
              </div>

              <div className="flex gap-3">
                <Button
                  type="submit"
                  disabled={uploading}
                  className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  {uploading
                    ? editingSeries
                      ? "Updating..."
                      : "Adding..."
                    : editingSeries
                      ? "Update Series"
                      : "Add Series"}
                </Button>
                {editingSeries && (
                  <Button
                    type="button"
                    onClick={handleCancelEdit}
                    variant="outline"
                    className="border-border bg-transparent"
                  >
                    Cancel
                  </Button>
                )}
              </div>
            </form>
          </Card>

          {/* Series Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 md:gap-4">
            {series.map((s) => (
              <Card key={s.id} className="bg-card border-border overflow-hidden hover:border-primary/50 transition">
                <div className="relative aspect-[2/3] bg-muted">
                  <img src={s.image || "/placeholder.svg"} alt={s.title} className="w-full h-full object-cover" />
                  <div className="absolute top-1.5 right-1.5 bg-blue-600 text-white px-1.5 py-0.5 rounded text-[10px]">
                    {s.episodes?.length || 0} Eps
                  </div>
                </div>
                <div className="p-2.5">
                  <h3 className="font-semibold text-foreground text-sm mb-1 truncate">{s.title}</h3>
                  <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
                    <span>{s.category}</span>
                    <span className="text-yellow-500 flex items-center gap-0.5">
                      <Star className="w-3 h-3 fill-yellow-500" />
                      {s.rating}
                    </span>
                  </div>
                  <div className="space-y-1.5">
                    <Button
                      onClick={() => handleEditSeries(s)}
                      size="sm"
                      className="w-full h-7 text-xs bg-green-600 hover:bg-green-700 text-white"
                    >
                      <Edit className="w-3 h-3 mr-1" />
                      Edit
                    </Button>
                    <Button
                      onClick={() => handleDeleteSeries(s.id)}
                      variant="destructive"
                      size="sm"
                      className="w-full h-7 text-xs"
                    >
                      <Trash2 className="w-3 h-3 mr-1" />
                      Delete
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
