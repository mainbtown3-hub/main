"use client"

import type React from "react"
import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import Sidebar from "@/components/sidebar"
import AdminNav from "@/components/admin-nav"
import AdminMobileNav from "@/components/admin-mobile-nav"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { database } from "@/lib/firebase"
import { ref as dbRef, push, get, remove, update } from "firebase/database"
import { Star, Trash2, Edit, Music } from "lucide-react"

interface MusicVideo {
  id: string
  title: string
  image: string
  rating: number
  year: number
  category: string
  streamlink: string
  artist?: string
}

export default function MusicManagement() {
  const { user, loading, isAdmin } = useAuth()
  const router = useRouter()
  const [musicVideos, setMusicVideos] = useState<MusicVideo[]>([])
  const [newMusic, setNewMusic] = useState({
    title: "",
    image: "",
    rating: 7.5,
    year: new Date().getFullYear(),
    category: "Music",
    streamlink: "",
    artist: "",
  })
  const [uploading, setUploading] = useState(false)
  const [successMessage, setSuccessMessage] = useState("")
  const [editingMusic, setEditingMusic] = useState<MusicVideo | null>(null)

  useEffect(() => {
    if (!loading && (!user || !isAdmin)) {
      router.push("/login")
    }
  }, [user, loading, isAdmin, router])

  useEffect(() => {
    if (isAdmin) {
      loadMusicVideos()
    }
  }, [isAdmin])

  const loadMusicVideos = async () => {
    try {
      const musicRef = dbRef(database, "movies")
      const snapshot = await get(musicRef)
      if (snapshot.exists()) {
        const data = snapshot.val()
        const musicList = Object.entries(data)
          .map(([id, value]: any) => ({ id, ...value }))
          .filter((item: any) => item.category?.toLowerCase() === "music")
        setMusicVideos(musicList)
      }
    } catch (error) {
      console.error("Error loading music videos:", error)
    }
  }

  const handleAddMusic = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!newMusic.image.trim() || !newMusic.title.trim() || !newMusic.streamlink.trim()) {
      alert("Please fill in all required fields")
      return
    }

    setUploading(true)
    try {
      const musicRef = dbRef(database, "movies")
      await push(musicRef, {
        title: newMusic.title,
        image: newMusic.image,
        rating: Number.parseFloat(newMusic.rating.toString()),
        year: newMusic.year,
        category: "Music",
        streamlink: newMusic.streamlink,
        artist: newMusic.artist,
        type: "music",
        createdAt: new Date().toISOString(),
      })

      setSuccessMessage("Music video added successfully!")
      setTimeout(() => setSuccessMessage(""), 3000)
      setNewMusic({
        title: "",
        image: "",
        rating: 7.5,
        year: new Date().getFullYear(),
        category: "Music",
        streamlink: "",
        artist: "",
      })
      loadMusicVideos()
    } catch (error) {
      console.error("Error adding music video:", error)
      alert("Error adding music video. Please try again.")
    } finally {
      setUploading(false)
    }
  }

  const handleDeleteMusic = async (id: string) => {
    if (confirm("Are you sure you want to delete this music video?")) {
      try {
        await remove(dbRef(database, `movies/${id}`))
        setSuccessMessage("Music video deleted successfully!")
        setTimeout(() => setSuccessMessage(""), 3000)
        loadMusicVideos()
      } catch (error) {
        console.error("Error deleting music video:", error)
      }
    }
  }

  const handleEditMusic = (music: MusicVideo) => {
    setEditingMusic(music)
    setNewMusic({
      title: music.title,
      image: music.image,
      rating: music.rating,
      year: music.year,
      category: "Music",
      streamlink: music.streamlink,
      artist: music.artist || "",
    })
  }

  const handleUpdateMusic = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!editingMusic) return

    if (!newMusic.image.trim() || !newMusic.title.trim() || !newMusic.streamlink.trim()) {
      alert("Please fill in all required fields")
      return
    }

    setUploading(true)
    try {
      await update(dbRef(database, `movies/${editingMusic.id}`), {
        title: newMusic.title,
        image: newMusic.image,
        rating: Number.parseFloat(newMusic.rating.toString()),
        year: newMusic.year,
        category: "Music",
        streamlink: newMusic.streamlink,
        artist: newMusic.artist,
        updatedAt: new Date().toISOString(),
      })

      setSuccessMessage("Music video updated successfully!")
      setTimeout(() => setSuccessMessage(""), 3000)
      setEditingMusic(null)
      setNewMusic({
        title: "",
        image: "",
        rating: 7.5,
        year: new Date().getFullYear(),
        category: "Music",
        streamlink: "",
        artist: "",
      })
      loadMusicVideos()
    } catch (error) {
      console.error("Error updating music video:", error)
      alert("Error updating music video. Please try again.")
    } finally {
      setUploading(false)
    }
  }

  const handleCancelEdit = () => {
    setEditingMusic(null)
    setNewMusic({
      title: "",
      image: "",
      rating: 7.5,
      year: new Date().getFullYear(),
      category: "Music",
      streamlink: "",
      artist: "",
    })
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-foreground text-xl">Loading...</div>
      </div>
    )
  }

  if (!isAdmin) {
    return null
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Desktop sidebar */}
      <div className="hidden lg:block">
        <Sidebar onFilterChange={() => {}} activeFilter="settings" />
      </div>

      {/* Admin Navigation */}
      <AdminNav />
      <AdminMobileNav />

      {/* Main content with proper padding */}
      <main className="lg:ml-48 pt-14 pb-20 md:pb-6 px-3 md:px-6 min-h-screen">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-6">
            <h1 className="text-2xl md:text-3xl font-bold text-foreground flex items-center gap-2">
              <Music className="w-7 h-7" />
              Manage Music Videos
            </h1>
            <p className="text-sm text-muted-foreground mt-1">Total: {musicVideos.length} music videos</p>
          </div>

          {successMessage && (
            <div className="mb-4 p-3 bg-green-500/20 border border-green-500/30 rounded text-green-500 text-sm">
              {successMessage}
            </div>
          )}

          {/* Add/Edit Form */}
          <Card className="bg-card border-border p-4 md:p-6 mb-6">
            <h2 className="text-lg font-bold text-foreground mb-4">
              {editingMusic ? "Edit Music Video" : "Add New Music Video"}
            </h2>
            <form onSubmit={editingMusic ? handleUpdateMusic : handleAddMusic} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Video Title *</label>
                  <Input
                    value={newMusic.title}
                    onChange={(e) => setNewMusic({ ...newMusic, title: e.target.value })}
                    className="bg-muted border-border text-foreground"
                    placeholder="Enter music video title"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Artist Name</label>
                  <Input
                    value={newMusic.artist}
                    onChange={(e) => setNewMusic({ ...newMusic, artist: e.target.value })}
                    className="bg-muted border-border text-foreground"
                    placeholder="Enter artist name"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Stream Link *</label>
                  <Input
                    type="url"
                    value={newMusic.streamlink}
                    onChange={(e) => setNewMusic({ ...newMusic, streamlink: e.target.value })}
                    className="bg-muted border-border text-foreground"
                    placeholder="https://example.com/stream/video.mp4"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Rating (0-10)</label>
                  <Input
                    type="number"
                    min="0"
                    max="10"
                    step="0.1"
                    value={newMusic.rating}
                    onChange={(e) => setNewMusic({ ...newMusic, rating: Number.parseFloat(e.target.value) })}
                    className="bg-muted border-border text-foreground"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Year</label>
                  <Input
                    type="number"
                    value={newMusic.year}
                    onChange={(e) => setNewMusic({ ...newMusic, year: Number.parseInt(e.target.value) })}
                    className="bg-muted border-border text-foreground"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Thumbnail Image URL *</label>
                  <Input
                    type="url"
                    value={newMusic.image}
                    onChange={(e) => setNewMusic({ ...newMusic, image: e.target.value })}
                    className="bg-muted border-border text-foreground"
                    placeholder="https://example.com/image.jpg"
                    required
                  />
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  type="submit"
                  disabled={uploading}
                  className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  {uploading
                    ? editingMusic
                      ? "Updating..."
                      : "Adding..."
                    : editingMusic
                      ? "Update Music Video"
                      : "Add Music Video"}
                </Button>
                {editingMusic && (
                  <Button
                    type="button"
                    onClick={handleCancelEdit}
                    variant="outline"
                    className="border-border bg-transparent"
                  >
                    Cancel
                  </Button>
                )}
              </div>
            </form>
          </Card>

          {/* Music Videos Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 md:gap-4">
            {musicVideos.map((music) => (
              <Card key={music.id} className="bg-card border-border overflow-hidden hover:border-primary/50 transition">
                <div className="relative aspect-[2/3] bg-muted">
                  <img
                    src={music.image || "/placeholder.svg"}
                    alt={music.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-1.5 left-1.5 bg-purple-600 text-white px-1.5 py-0.5 rounded text-[10px] flex items-center gap-0.5">
                    <Music className="w-2.5 h-2.5" />
                    Music
                  </div>
                </div>
                <div className="p-2.5">
                  <h3 className="font-semibold text-foreground text-sm mb-0.5 truncate">{music.title}</h3>
                  {music.artist && <p className="text-xs text-muted-foreground mb-1 truncate">{music.artist}</p>}
                  <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
                    <span>{music.year}</span>
                    <span className="text-yellow-500 flex items-center gap-0.5">
                      <Star className="w-3 h-3 fill-yellow-500" />
                      {music.rating}
                    </span>
                  </div>
                  <div className="space-y-1.5">
                    <Button
                      onClick={() => handleEditMusic(music)}
                      size="sm"
                      className="w-full h-7 text-xs bg-green-600 hover:bg-green-700 text-white"
                    >
                      <Edit className="w-3 h-3 mr-1" />
                      Edit
                    </Button>
                    <Button
                      onClick={() => handleDeleteMusic(music.id)}
                      variant="destructive"
                      size="sm"
                      className="w-full h-7 text-xs"
                    >
                      <Trash2 className="w-3 h-3 mr-1" />
                      Delete
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
