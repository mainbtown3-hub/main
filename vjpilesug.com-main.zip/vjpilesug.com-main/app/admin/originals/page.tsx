"use client"

import type React from "react"
import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import Sidebar from "@/components/sidebar"
import AdminNav from "@/components/admin-nav"
import AdminMobileNav from "@/components/admin-mobile-nav"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { database } from "@/lib/firebase"
import { ref as dbRef, push, get, remove, update } from "firebase/database"
import { Star, Trash2, Edit } from "lucide-react"

interface Original {
  id: string
  title: string
  image: string
  rating: number
  year: number
  category: string
  streamlink: string
}

const CATEGORIES = ["Action", "Romance", "Animation", "Horror", "Special", "Drabor", "Comedy", "Drama"]

export default function OriginalsManagement() {
  const { user, loading, isAdmin } = useAuth()
  const router = useRouter()
  const [originals, setOriginals] = useState<Original[]>([])
  const [newOriginal, setNewOriginal] = useState({
    title: "",
    image: "",
    rating: 7.5,
    year: new Date().getFullYear(),
    category: "Animation",
    streamlink: "",
  })
  const [uploading, setUploading] = useState(false)
  const [successMessage, setSuccessMessage] = useState("")
  const [editingOriginal, setEditingOriginal] = useState<Original | null>(null)

  useEffect(() => {
    if (!loading && (!user || !isAdmin)) {
      router.push("/login")
    }
  }, [user, loading, isAdmin, router])

  useEffect(() => {
    if (isAdmin) {
      loadOriginals()
    }
  }, [isAdmin])

  const loadOriginals = async () => {
    try {
      const originalsRef = dbRef(database, "originals")
      const snapshot = await get(originalsRef)
      if (snapshot.exists()) {
        const data = snapshot.val()
        const originalsList = Object.entries(data).map(([id, value]: any) => ({
          id,
          ...value,
        }))
        setOriginals(originalsList)
      }
    } catch (error) {
      console.error("Error loading originals:", error)
    }
  }

  const handleAddOriginal = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!newOriginal.image.trim() || !newOriginal.title.trim() || !newOriginal.streamlink.trim()) {
      alert("Please fill in all required fields")
      return
    }

    setUploading(true)
    try {
      const originalsRef = dbRef(database, "originals")
      await push(originalsRef, {
        title: newOriginal.title,
        image: newOriginal.image,
        rating: Number.parseFloat(newOriginal.rating.toString()),
        year: newOriginal.year,
        category: newOriginal.category,
        streamlink: newOriginal.streamlink,
        createdAt: new Date().toISOString(),
      })

      setSuccessMessage("Original content added successfully!")
      setTimeout(() => setSuccessMessage(""), 3000)
      setNewOriginal({
        title: "",
        image: "",
        rating: 7.5,
        year: new Date().getFullYear(),
        category: "Animation",
        streamlink: "",
      })
      loadOriginals()
    } catch (error) {
      console.error("Error adding original:", error)
      alert("Error adding original. Please try again.")
    } finally {
      setUploading(false)
    }
  }

  const handleEditOriginal = (original: Original) => {
    setEditingOriginal(original)
    setNewOriginal({
      title: original.title,
      image: original.image,
      rating: original.rating,
      year: original.year,
      category: original.category,
      streamlink: original.streamlink,
    })
  }

  const handleUpdateOriginal = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!editingOriginal) return

    if (!newOriginal.image.trim() || !newOriginal.title.trim() || !newOriginal.streamlink.trim()) {
      alert("Please fill in all required fields")
      return
    }

    setUploading(true)
    try {
      await update(dbRef(database, `originals/${editingOriginal.id}`), {
        title: newOriginal.title,
        image: newOriginal.image,
        rating: Number.parseFloat(newOriginal.rating.toString()),
        year: newOriginal.year,
        category: newOriginal.category,
        streamlink: newOriginal.streamlink,
        updatedAt: new Date().toISOString(),
      })

      setSuccessMessage("Original updated successfully!")
      setTimeout(() => setSuccessMessage(""), 3000)
      setEditingOriginal(null)
      setNewOriginal({
        title: "",
        image: "",
        rating: 7.5,
        year: new Date().getFullYear(),
        category: "Animation",
        streamlink: "",
      })
      loadOriginals()
    } catch (error) {
      console.error("Error updating original:", error)
      alert("Error updating original. Please try again.")
    } finally {
      setUploading(false)
    }
  }

  const handleCancelEdit = () => {
    setEditingOriginal(null)
    setNewOriginal({
      title: "",
      image: "",
      rating: 7.5,
      year: new Date().getFullYear(),
      category: "Animation",
      streamlink: "",
    })
  }

  const handleDeleteOriginal = async (id: string) => {
    if (confirm("Are you sure you want to delete this original?")) {
      try {
        await remove(dbRef(database, `originals/${id}`))
        setSuccessMessage("Original deleted successfully!")
        setTimeout(() => setSuccessMessage(""), 3000)
        loadOriginals()
      } catch (error) {
        console.error("Error deleting original:", error)
      }
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-foreground text-xl">Loading...</div>
      </div>
    )
  }

  if (!isAdmin) {
    return null
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Desktop sidebar */}
      <div className="hidden lg:block">
        <Sidebar onFilterChange={() => {}} activeFilter="settings" />
      </div>

      {/* Admin Navigation */}
      <AdminNav />
      <AdminMobileNav />

      {/* Main content with proper padding */}
      <main className="lg:ml-48 pt-14 pb-20 md:pb-6 px-3 md:px-6 min-h-screen">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-6">
            <h1 className="text-2xl md:text-3xl font-bold text-foreground">Manage Originals</h1>
            <p className="text-sm text-muted-foreground mt-1">Total: {originals.length} originals</p>
          </div>

          {successMessage && (
            <div className="mb-4 p-3 bg-green-500/20 border border-green-500/30 rounded text-green-500 text-sm">
              {successMessage}
            </div>
          )}

          {/* Add/Edit Form */}
          <Card className="bg-card border-border p-4 md:p-6 mb-6">
            <h2 className="text-lg font-bold text-foreground mb-4">
              {editingOriginal ? "Edit Original" : "Add New Original"}
            </h2>
            <form onSubmit={editingOriginal ? handleUpdateOriginal : handleAddOriginal} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Title *</label>
                  <Input
                    value={newOriginal.title}
                    onChange={(e) => setNewOriginal({ ...newOriginal, title: e.target.value })}
                    className="bg-muted border-border text-foreground"
                    placeholder="Enter title"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Category *</label>
                  <select
                    value={newOriginal.category}
                    onChange={(e) => setNewOriginal({ ...newOriginal, category: e.target.value })}
                    className="w-full bg-muted border border-border text-foreground rounded-md px-3 py-2 text-sm"
                    required
                  >
                    {CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Stream Link *</label>
                  <Input
                    type="url"
                    value={newOriginal.streamlink}
                    onChange={(e) => setNewOriginal({ ...newOriginal, streamlink: e.target.value })}
                    className="bg-muted border-border text-foreground"
                    placeholder="https://example.com/stream/video.mp4"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Rating (0-10)</label>
                  <Input
                    type="number"
                    min="0"
                    max="10"
                    step="0.1"
                    value={newOriginal.rating}
                    onChange={(e) => setNewOriginal({ ...newOriginal, rating: Number.parseFloat(e.target.value) })}
                    className="bg-muted border-border text-foreground"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Year</label>
                  <Input
                    type="number"
                    value={newOriginal.year}
                    onChange={(e) => setNewOriginal({ ...newOriginal, year: Number.parseInt(e.target.value) })}
                    className="bg-muted border-border text-foreground"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Poster Image URL *</label>
                  <Input
                    type="url"
                    value={newOriginal.image}
                    onChange={(e) => setNewOriginal({ ...newOriginal, image: e.target.value })}
                    className="bg-muted border-border text-foreground"
                    placeholder="https://example.com/image.jpg"
                    required
                  />
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  type="submit"
                  disabled={uploading}
                  className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  {uploading
                    ? editingOriginal
                      ? "Updating..."
                      : "Adding..."
                    : editingOriginal
                      ? "Update Original"
                      : "Add Original"}
                </Button>
                {editingOriginal && (
                  <Button
                    type="button"
                    onClick={handleCancelEdit}
                    variant="outline"
                    className="border-border bg-transparent"
                  >
                    Cancel
                  </Button>
                )}
              </div>
            </form>
          </Card>

          {/* Originals Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 md:gap-4">
            {originals.map((original) => (
              <Card
                key={original.id}
                className="bg-card border-border overflow-hidden hover:border-primary/50 transition"
              >
                <div className="relative aspect-[2/3] bg-muted">
                  <img
                    src={original.image || "/placeholder.svg"}
                    alt={original.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-2.5">
                  <h3 className="font-semibold text-foreground text-sm mb-1 truncate">{original.title}</h3>
                  <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
                    <span>{original.category}</span>
                    <span className="text-yellow-500 flex items-center gap-0.5">
                      <Star className="w-3 h-3 fill-yellow-500" />
                      {original.rating}
                    </span>
                  </div>
                  <div className="space-y-1.5">
                    <Button
                      onClick={() => handleEditOriginal(original)}
                      size="sm"
                      className="w-full h-7 text-xs bg-green-600 hover:bg-green-700 text-white"
                    >
                      <Edit className="w-3 h-3 mr-1" />
                      Edit
                    </Button>
                    <Button
                      onClick={() => handleDeleteOriginal(original.id)}
                      variant="destructive"
                      size="sm"
                      className="w-full h-7 text-xs"
                    >
                      <Trash2 className="w-3 h-3 mr-1" />
                      Delete
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
